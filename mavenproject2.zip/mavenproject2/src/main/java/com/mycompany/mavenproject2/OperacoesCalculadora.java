package com.mycompany.mavenproject2;

public class OperacoesCalculadora 
{
    public float somar(float nro1, float nro2)
    {   
        return nro1 + nro2;  
    }
    
    public float sub(float nro1, float nro2)
    {
        return nro1 - nro2;
    }
    
    public float mult(float nro1, float nro2)
    {
        return nro1 * nro2;
    }
    
    public float div(float nro1, float nro2)
    {
        return nro1 / nro2;
    }
    
    public float potencia(float nro1)
    {
        return nro1 * nro1;
    }
    
    public float raiz(float nro1)
    {
        return (float) Math.sqrt(nro1);
        
    }
    
    
    
}
