package com.mycompany.prj_padrao_factory;

public class CheesePizza extends Pizza
{
    public CheesePizza()
    {
        name = "Cheese Pizza";
        dough = "Regular Crust";
        sauce = "Marinara Pizza Sauce";
        toppings.add("Fresh Mozzarella");
        toppings.add("Parseman");
        
    } 
    
}
