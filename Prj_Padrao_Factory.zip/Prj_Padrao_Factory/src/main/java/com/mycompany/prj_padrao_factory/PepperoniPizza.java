package com.mycompany.prj_padrao_factory;

public class PepperoniPizza extends Pizza
{
   public PepperoniPizza()
   {
       name = "Pepperoni Pizza";
       dough = "Crust";
       sauce = "Marinara sauce";
       toppings.add("Sliced Pepperoni");
       toppings.add("Sliced Onion");
       toppings.add("Sliced parmesan cheese");
   }
}
